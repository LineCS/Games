# 🦄 Veronica & Cecilias Arkade

En lille samling browserspil i et magisk univers med enhjørninger, regnbuer og glimmer — lavet til Veronica (4 år) og Cecilia (8 år).

Hele arkaden er **én enkelt fil** (`index.html`). Der skal ikke installeres eller bygges noget — det virker bare, både på computer, tablet og telefon.

## Spillene

- **🃏 Vendespil** — find parrene. Vælg antal brikker og hvor rodet de ligger, tilmeld spillere, og se hvem der finder flest par. Hver spiller er en enhjørning i sin egen farve.
- **🫧 Boblebobbel** — klassisk bobleskyder. Sigt, skyd, og pop tre eller flere ens bobler.
- **⭐ Stjernefangst** — flyt enhjørningen og fang faldende stjerner og hjerter. Pas på bomberne!
- **🐱 Kattefamilien** — navngivne killinger dukker op i haven. Tryk på dem, så løber de hjem: lyserøde til Veronicas hus, lilla til Cecilias hus. Hver fanget kat giver +3 sekunder, så legen kan holdes i gang. Justér tempoet fra sneglefart til lynhurtigt med skyderen.
- **🦷 Red munden** — et hop-og-saml-løb inde i munden. Karius og Baktus har spredt slik ud, så hop over det (🍭🍬) og saml sundt (🥕🥒🍎🍞) for point. En sjælden madpakke 🍱 tæller dobbelt. Rammer man slik tre gange, rækker Baktus tunge, og man har tabt. Nå 100 point, så er munden reddet! To skydere styrer tempoet og mængden af slik, og der er en lille pause hver gang man fanger noget, så man når at se munden.
- **🎹 Spil sangen** — et "Piano Tiles"-spil. Vælg først en sang og et tempo, og tryk Start. Så falder farvede felter ned i fire baner (brede felter = lange toner, smalle = korte), og man sætter fingeren på tangenten forneden, lige når feltet rammer den lilla linje — så spilles tonen. Spil hele sangen igennem som en vinder. Man kan ikke tabe; til sidst vises, hvor mange toner man ramte. Sange: Twinkle Twinkle, Mester Jakob og Lille lam (frie melodier) samt tre originale pop/disco-numre, som er skrevet til spillet — Disco-enhjørning 🦄, Pink Party 💖 og Glimmer-disco ✨. Tre tempoer (🐢 langsom / normal / 🐇 hurtig). På computer kan man også bruge tasterne F, G, H, J.
- **🌙 Måneglimmer** — en måne-pige sidder på månen og drysser gyldent månestøv ✨ ned, mens en lille djævel i det andet hjørne kaster ild 🔥. Du er en helt almindelig pige forneden: flyt dig (træk med fingeren eller brug pilene) og fang månestøvet, men undgå ilden. Rammer ilden dig 10 gange, dør du. Saml 30 portioner månestøv, så vinder du. Runden er lang, og tempoet kan skrues op og ned med en skyder.

## Sådan prøver du det med det samme

Dobbeltklik på `index.html`, så åbner spillet i din browser.

## Sådan lægger du det på GitHub

1. Log ind på [github.com](https://github.com) og klik på **New** for at oprette et nyt repository (fx kaldet `arkade`). Sæt det til **Public**.
2. På repository-siden: klik **Add file → Upload files**, og træk `index.html` (og gerne denne `README.md`) ind. Klik **Commit changes**.

### Gør spillet til en hjemmeside (GitHub Pages)

Så kan I spille det fra en rigtig internetadresse — også på pigernes tablet.

3. Gå til **Settings** (øverst i dit repository) → **Pages** (i menuen til venstre).
4. Under **Branch** vælger du `main` og mappen `/ (root)`, og trykker **Save**.
5. Vent ca. et minut. Genindlæs siden, så viser GitHub en grøn boks med linket — typisk:

   `https://DIT-BRUGERNAVN.github.io/arkade/`

Det link kan du dele eller gemme som bogmærke på tabletten. 💜

## Teknisk

- Ingen afhængigheder ud over en skrifttype, der hentes fra Google Fonts (faldback til systemets skrifttype, hvis man er offline).
- Ren HTML, CSS og JavaScript i én fil — ingen build, ingen server.
